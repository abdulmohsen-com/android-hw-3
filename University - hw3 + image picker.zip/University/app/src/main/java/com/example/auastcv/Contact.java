package com.example.auastcv;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import static android.content.Intent.EXTRA_EMAIL;

public class Contact extends AppCompatActivity {
      private Button Back;
      private Button Phone;
      private Button Email;
      private Button Map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        Email = (Button)findViewById(R.id.btn_email);
        Phone = (Button)findViewById(R.id.BtnPhone);
        Back = (Button)findViewById(R.id.BtnBack);
        Map = (Button)findViewById(R.id.BtnMap);
        //__________________________________________________
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Contact.this , MainActivity.class);
                startActivity(intent);
            }
        });
        //_____________________________________________________
        Email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              try {
                    Intent sendemail = new Intent(Intent.ACTION_SEND);
                    sendemail.setData(Uri.parse("mailto:"));
                    sendemail.setType("message/rfc822");

                    sendemail.putExtra(Intent.EXTRA_EMAIL, "AUAST@gmail.com");
                    startActivity(sendemail);
                }catch (Exception e){}
            }
        });
        //___________________________________________
        Phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phone = "+96594431440";
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
        }
        });
        //_______________________________________
        Map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Contact.this , MapsActivity.class);
                startActivity(intent);
            }
        });

    }
       //___________________________________________

}