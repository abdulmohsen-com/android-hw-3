package com.example.auastcv;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Major extends AppCompatActivity {
    private EditText FirstName;
    private EditText SecondName;
    private EditText ThirdName;
    private EditText Age;
    private EditText School;
    private EditText Grade;
    private Button Back;
    private Button Next;
    Button btnChoose;
    ImageView Choose;
    private static final int IMAGE_PICK_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_major);
        FirstName = findViewById(R.id.etName1);
        SecondName = findViewById(R.id.etName2);
        ThirdName = findViewById(R.id.etName3);
        Age = findViewById(R.id.EtAge);
        School = findViewById(R.id.EtSchool);
        Grade = findViewById(R.id.EtGrade);
        Back = findViewById(R.id.BtnBack);
        Next = findViewById(R.id.BtnNext);
        Choose = findViewById(R.id.imageChoose);
        btnChoose = findViewById(R.id.BtnChoose);
//____________________________Image Picker__________________________________________________________
       btnChoose.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               // check runtime permission
               if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                   if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                           == PackageManager.PERMISSION_DENIED){
                       //permission not granted request it.
                       String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                       //Show popup for runtime permission.
                       requestPermissions(permissions, PERMISSION_CODE);

                   }
                   else {
                       //permission already granted
                       pickImageFromGallery();
                   }
               }
               else {
                   //system os less than marshmallow
                   pickImageFromGallery();
               }
           }
       });
//______________________________________________________________________________________
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Major.this , CV.class);
                startActivity(intent);
            }
        });
//______________________________________________________________________________________
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = FirstName.getText().toString() + " " + SecondName.getText().toString() + " " + ThirdName.getText().toString();
                String age = Age.getText().toString();
                String school = School.getText().toString();
                String grade = Grade.getText().toString();
                Intent j = new Intent(Major.this , CVFin.class);
                j.putExtra("1",name);
                j.putExtra("2",age);
                j.putExtra("3",school);
                j.putExtra("4",grade);
                startActivity(j);
            }
        });


    }

    private void pickImageFromGallery() {
    //intent to pick image
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_CODE);
    }
    //handle result of runtime permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case PERMISSION_CODE:{
                if  (grantResults.length > 0 && grantResults[0] ==
                 PackageManager.PERMISSION_GRANTED) {
                    //Permission was granted
                    pickImageFromGallery();
                }
                else {
                    //Permission was denied
                    Toast.makeText(this, "Permission Was Denied...!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    //handle result of picked image


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
            Choose.setImageURI(data.getData());
        }
    }
}