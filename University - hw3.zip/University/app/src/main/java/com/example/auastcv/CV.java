package com.example.auastcv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CV extends AppCompatActivity {
    private Button Back;
    private Button RE;
    private Button GME;
    private Button ND;
    private Button AT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_v);
        Back = (Button)findViewById(R.id.BtnBack);
        GME = (Button)findViewById(R.id.btn_GME);
        AT = (Button)findViewById(R.id.btn_AstroTechnology);
        ND = (Button)findViewById(R.id.btn_NerveDoctor);
        RE = (Button)findViewById(R.id.btn_Engineer);
        //___________________________________
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CV.this , MainActivity.class);
                startActivity(intent);
            }
        });
        //____________________________________________________
        AT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CV.this , Major.class);
                startActivity(intent);
            }
        });
        //____________________________________________________
        GME.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CV.this , Major.class);
                startActivity(intent);
            }
        });
        //____________________________________________________
        ND.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CV.this , Major.class);
                startActivity(intent);
            }
        });
        //____________________________________________________
        RE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CV.this , Major.class);
                startActivity(intent);
            }
        });
        //____________________________________________________


    }
}