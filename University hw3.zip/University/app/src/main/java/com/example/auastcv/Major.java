package com.example.auastcv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Major extends AppCompatActivity {
    private EditText FirstName;
    private EditText SecondName;
    private EditText ThirdName;
    private EditText Age;
    private EditText School;
    private EditText Grade;
    private Button Back;
    private Button Next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_major);
        FirstName = findViewById(R.id.etName1);
        SecondName = findViewById(R.id.etName2);
        ThirdName = findViewById(R.id.etName3);
        Age = findViewById(R.id.EtAge);
        School = findViewById(R.id.EtSchool);
        Grade = findViewById(R.id.EtGrade);
        Back = findViewById(R.id.BtnBack);
        Next = findViewById(R.id.BtnNext);
//______________________________________________________________________________________
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Major.this , CV.class);
                startActivity(intent);
            }
        });
//______________________________________________________________________________________
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = FirstName.getText().toString() + "" + SecondName.getText().toString() + "" + ThirdName.getText().toString();
                String age = Age.getText().toString();
                String school = School.getText().toString();
                String grade = Grade.getText().toString();
                Intent j = new Intent(Major.this , CVFin.class);
                j.putExtra("1",name);
                j.putExtra("2",age);
                j.putExtra("3",school);
                j.putExtra("4",grade);
                startActivity(j);
            }
        });


    }

}