package com.example.auastcv;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class CVFin extends AppCompatActivity {
     private TextView Name;
     private TextView Age;
     private TextView School;
     private TextView Grade;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_v_fin);
        Bundle airport = getIntent().getExtras();
        assert airport != null;
        String name = airport.getString("1");
        String age = airport.getString("2");
        String school = airport.getString("3");
        String grade = airport.getString("4");
        Name = findViewById(R.id.TvName);
        Age = findViewById(R.id.TvAge);
        School = findViewById(R.id.TvSchool);
        Grade = findViewById(R.id.TvGrade);
        Name.setText(name);
        Age.setText(age);
        School.setText(school);
        Grade.setText(grade);

    }
}